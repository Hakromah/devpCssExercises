Rewrite the rules using the CSS custom properties.

**Suggestion**:

Use the `:root `selector, defining there all the properties and use them in the `body`and `.ball `selectors
